<?php

namespace InvisibleReCaptcha\Modules\Settings;


use InvisibleReCaptcha\Modules\BasePublicModule;

class SettingsPublicModule extends BasePublicModule
{
	public function __construct()
	{
		parent::__construct();
	}
}