=== WP Lorem ipsum ===

Contributors: matteomanna, kraein
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=matteomanna87%40gmail%2ecom
Tags: post, lorem ipsum, page, post type, database, post thumbnail
Requires at least: 4.0
Tested up to: 4.9
Stable tag: 2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

WP Lorem ipsum automatically create new fake posts to fill the database and get a very good impression for your website.



== Description ==

This plugin simplifies the life of WordPress users.
Now users can automatically create new fake posts to fill the database. It's possible select numbers of posts, post types, post status, post author and post thumbnail. Plugin available on [GitHub](https://github.com/MatteoManna/WP-Lorem-Ipsum).



== Installation ==

1. Upload `wp-lorem-ipsum` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the "Plugins" menu in WordPress
3. Now you have a new option through the "Settings" menu in WordPress



== Frequently Asked Questions ==

= Can I choose the post type? =

Yes, you can choose number of posts, post type, post author, post status and if the posts will have post thumbnail.

= Can I upload fake thumbnails? =

When you click "Send" your posts will have random post thumbnails. After that you can edit single posts and upload your thumbnails from your media library.



== Screenshots ==

1. Sample view of the plugin page.
2. A view of the posts archive with the new fake posts.
3. A single view of new fake post with title, content, excerpt and post thumbnail.



== Changelog ==

= 1.0 =
* Release Date - 29 March 2017

= 2.0 =
* Release Date - 13 July 2017

= 2.1 =
* Release Date - 23 November 2017



== Upgrade Notice ==

= 1.0 =
* Release Date - 29 March 2017

= 2.0 =
* Release Date - 13 July 2017

= 2.1 =
* Release Date - 23 November 2017