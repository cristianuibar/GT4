<?php
//* When I have them working together, it's like a beautiful kaleidoscope. - Ornette Coleman
