<?php
/**
 * Communication - the human connection - is the key to personal and career success.
 *
 * - Paul J. Meyer
 */
